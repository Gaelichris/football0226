# Google Research Football - Windows Build Script (PowerShell)
# Run this script in PowerShell as Administrator

param(
    [switch]$SkipVcpkg,
    [switch]$SkipBuild,
    [switch]$Help
)

$ErrorActionPreference = "Stop"

Write-Host "============================================" -ForegroundColor Cyan
Write-Host " Google Research Football Windows Builder" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

if ($Help) {
    Write-Host "Usage: .\build_windows.ps1 [-SkipVcpkg] [-SkipBuild] [-Help]"
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -SkipVcpkg  Skip vcpkg installation and dependency setup"
    Write-Host "  -SkipBuild  Skip gfootball compilation (use existing)"
    Write-Host "  -Help       Show this help message"
    exit 0
}

# Check prerequisites
function Check-Command($cmd) {
    return [bool](Get-Command $cmd -ErrorAction SilentlyContinue)
}

Write-Host "[1/6] Checking prerequisites..." -ForegroundColor Yellow

if (-not (Check-Command "python")) {
    Write-Host "[ERROR] Python not found. Install from https://python.org" -ForegroundColor Red
    exit 1
}
Write-Host "  [OK] Python found" -ForegroundColor Green

if (-not (Check-Command "git")) {
    Write-Host "[ERROR] Git not found. Install from https://git-scm.com" -ForegroundColor Red
    exit 1
}
Write-Host "  [OK] Git found" -ForegroundColor Green

# Setup vcpkg
if (-not $SkipVcpkg) {
    Write-Host ""
    Write-Host "[2/6] Setting up vcpkg..." -ForegroundColor Yellow
    
    if (-not $env:VCPKG_ROOT) {
        $vcpkgPath = "$env:USERPROFILE\vcpkg"
        if (-not (Test-Path $vcpkgPath)) {
            Write-Host "  Cloning vcpkg..."
            git clone https://github.com/Microsoft/vcpkg.git $vcpkgPath
        }
        Set-Location $vcpkgPath
        if (-not (Test-Path "vcpkg.exe")) {
            Write-Host "  Bootstrapping vcpkg..."
            .\bootstrap-vcpkg.bat
        }
        $env:VCPKG_ROOT = $vcpkgPath
        [Environment]::SetEnvironmentVariable("VCPKG_ROOT", $vcpkgPath, "User")
    }
    
    Write-Host "  VCPKG_ROOT = $env:VCPKG_ROOT" -ForegroundColor Green
    
    Write-Host "  Installing dependencies (this may take 10-30 minutes)..."
    & "$env:VCPKG_ROOT\vcpkg.exe" install `
        sdl2:x64-windows `
        sdl2-image:x64-windows `
        sdl2-ttf:x64-windows `
        sdl2-gfx:x64-windows `
        boost-python:x64-windows `
        boost-filesystem:x64-windows `
        boost-thread:x64-windows `
        boost-system:x64-windows
}

# Install Python dependencies
Write-Host ""
Write-Host "[3/6] Installing Python dependencies..." -ForegroundColor Yellow
python -m pip install --upgrade pip setuptools wheel
python -m pip install pyinstaller pygame opencv-python psutil numpy absl-py six "gym<=0.21.0"

# Clone and build gfootball
if (-not $SkipBuild) {
    Write-Host ""
    Write-Host "[4/6] Building gfootball..." -ForegroundColor Yellow
    
    $buildDir = "$PSScriptRoot\build"
    if (-not (Test-Path $buildDir)) {
        New-Item -ItemType Directory -Path $buildDir | Out-Null
    }
    Set-Location $buildDir
    
    if (-not (Test-Path "football")) {
        Write-Host "  Cloning repository..."
        git clone https://github.com/google-research/football.git
    }
    
    Set-Location football
    Write-Host "  Compiling (this may take 5-10 minutes)..."
    python -m pip install .
}

# Create PyInstaller package
Write-Host ""
Write-Host "[5/6] Creating executable with PyInstaller..." -ForegroundColor Yellow

Set-Location $PSScriptRoot
Copy-Item "launcher.py" "$buildDir\football\" -Force
Copy-Item "gfootball_game.spec" "$buildDir\football\" -Force
Set-Location "$buildDir\football"

pyinstaller gfootball_game.spec --clean --noconfirm

# Copy data files
$enginePath = python -c "import gfootball_engine; import os; print(os.path.dirname(gfootball_engine.__file__))"
Copy-Item -Path "$enginePath\data" -Destination "dist\gfootball\gfootball_engine\data" -Recurse -Force
Copy-Item -Path "$enginePath\fonts" -Destination "dist\gfootball\gfootball_engine\fonts" -Recurse -Force

# Create NSIS installer
Write-Host ""
Write-Host "[6/6] Creating Windows installer..." -ForegroundColor Yellow

Copy-Item "$PSScriptRoot\installer.nsi" "." -Force
Copy-Item "$PSScriptRoot\..\football0226\LICENSE" "." -Force -ErrorAction SilentlyContinue

if (Check-Command "makensis") {
    makensis installer.nsi
    Move-Item "GFootball_Setup.exe" "$PSScriptRoot\" -Force
    Write-Host ""
    Write-Host "============================================" -ForegroundColor Green
    Write-Host " BUILD COMPLETE!" -ForegroundColor Green
    Write-Host "============================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Installer: $PSScriptRoot\GFootball_Setup.exe" -ForegroundColor Cyan
} else {
    Write-Host "[WARNING] NSIS not found. Skipping installer creation." -ForegroundColor Yellow
    Write-Host "You can manually run: makensis installer.nsi" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Portable version available at: $buildDir\football\dist\gfootball\" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "Done!" -ForegroundColor Green
