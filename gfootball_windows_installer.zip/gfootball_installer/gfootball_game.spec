# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec file for Google Research Football"""

import os
import sys
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None

# Collect all gfootball submodules
hiddenimports = collect_submodules('gfootball')
hiddenimports += ['pygame', 'cv2', 'numpy', 'gym', 'psutil', 'six', 'absl']

# Find gfootball_engine location
import gfootball_engine
engine_path = os.path.dirname(gfootball_engine.__file__)

# Data files to include
datas = [
    (os.path.join(engine_path, 'data'), 'gfootball_engine/data'),
    (os.path.join(engine_path, 'fonts'), 'gfootball_engine/fonts'),
]

# Add gfootball scenarios
import gfootball
gfootball_path = os.path.dirname(gfootball.__file__)
datas.append((os.path.join(gfootball_path, 'scenarios'), 'gfootball/scenarios'))

# Binary files (the compiled C++ engine)
binaries = []
for f in os.listdir(engine_path):
    if f.endswith('.pyd') or f.endswith('.dll'):
        binaries.append((os.path.join(engine_path, f), 'gfootball_engine'))

a = Analysis(
    ['launcher.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='GFootball',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,  # Set to True if you want console window
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='football.ico' if os.path.exists('football.ico') else None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='gfootball',
)
