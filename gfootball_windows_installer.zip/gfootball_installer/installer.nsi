; Google Research Football Windows Installer
; NSIS Script

!include "MUI2.nsh"

; Basic Info
Name "Google Research Football"
OutFile "GFootball_Setup.exe"
InstallDir "$PROGRAMFILES64\Google Research Football"
InstallDirRegKey HKLM "Software\GFootball" "Install_Dir"
RequestExecutionLevel admin

; Version Info
VIProductVersion "2.10.3.0"
VIAddVersionKey "ProductName" "Google Research Football"
VIAddVersionKey "CompanyName" "Google Research"
VIAddVersionKey "FileDescription" "Football Reinforcement Learning Environment"
VIAddVersionKey "FileVersion" "2.10.3"
VIAddVersionKey "ProductVersion" "2.10.3"
VIAddVersionKey "LegalCopyright" "Copyright Google LLC"

; Modern UI Configuration
!define MUI_ABORTWARNING
!define MUI_ICON "${NSISDIR}\Contrib\Graphics\Icons\modern-install.ico"
!define MUI_UNICON "${NSISDIR}\Contrib\Graphics\Icons\modern-uninstall.ico"

; Pages
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "LICENSE"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

; Language
!insertmacro MUI_LANGUAGE "English"
!insertmacro MUI_LANGUAGE "SimpChinese"

; Installation Section
Section "Google Research Football" SecMain
    SetOutPath "$INSTDIR"
    
    ; Copy all files from dist/gfootball
    File /r "dist\gfootball\*.*"
    
    ; Create Start Menu shortcuts
    CreateDirectory "$SMPROGRAMS\Google Research Football"
    CreateShortcut "$SMPROGRAMS\Google Research Football\GFootball.lnk" "$INSTDIR\GFootball.exe"
    CreateShortcut "$SMPROGRAMS\Google Research Football\Uninstall.lnk" "$INSTDIR\uninstall.exe"
    
    ; Create Desktop shortcut
    CreateShortcut "$DESKTOP\Google Research Football.lnk" "$INSTDIR\GFootball.exe"
    
    ; Write registry keys
    WriteRegStr HKLM "Software\GFootball" "Install_Dir" "$INSTDIR"
    
    ; Write uninstall information
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\GFootball" "DisplayName" "Google Research Football"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\GFootball" "UninstallString" '"$INSTDIR\uninstall.exe"'
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\GFootball" "DisplayIcon" "$INSTDIR\GFootball.exe"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\GFootball" "Publisher" "Google Research"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\GFootball" "DisplayVersion" "2.10.3"
    WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\GFootball" "NoModify" 1
    WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\GFootball" "NoRepair" 1
    
    ; Create uninstaller
    WriteUninstaller "$INSTDIR\uninstall.exe"
SectionEnd

; Install Visual C++ Redistributable if needed
Section "Visual C++ Runtime" SecVCRedist
    SetOutPath "$TEMP"
    
    ; Check if VC++ Redistributable is installed
    ReadRegStr $0 HKLM "SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64" "Installed"
    StrCmp $0 "1" vcredist_done
    
    ; Download and install VC++ Redistributable
    ; Note: In production, include the redistributable in the installer
    DetailPrint "Installing Visual C++ Redistributable..."
    ; File "vc_redist.x64.exe"
    ; ExecWait '"$TEMP\vc_redist.x64.exe" /install /quiet /norestart'
    
    vcredist_done:
SectionEnd

; Uninstaller Section
Section "Uninstall"
    ; Remove files
    RMDir /r "$INSTDIR"
    
    ; Remove Start Menu shortcuts
    RMDir /r "$SMPROGRAMS\Google Research Football"
    
    ; Remove Desktop shortcut
    Delete "$DESKTOP\Google Research Football.lnk"
    
    ; Remove registry keys
    DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\GFootball"
    DeleteRegKey HKLM "Software\GFootball"
SectionEnd

; Section Descriptions
!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
    !insertmacro MUI_DESCRIPTION_TEXT ${SecMain} "Install Google Research Football game files"
    !insertmacro MUI_DESCRIPTION_TEXT ${SecVCRedist} "Install required Visual C++ Runtime (if not present)"
!insertmacro MUI_FUNCTION_DESCRIPTION_END
