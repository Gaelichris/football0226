# Google Research Football - Windows Installer Builder

This package contains scripts to build a Windows installer for Google Research Football.

## Prerequisites

Before running the build script, you need to install:

### 1. Python 3.8 or higher
- Download from: https://www.python.org/downloads/
- During installation, check "Add Python to PATH"

### 2. Git
- Download from: https://git-scm.com/download/win

### 3. Visual Studio Build Tools
- Download from: https://visualstudio.microsoft.com/visual-cpp-build-tools/
- Install "Desktop development with C++"

### 4. NSIS (Nullsoft Scriptable Install System)
- Download from: https://nsis.sourceforge.io/Download
- Add NSIS to your PATH

### 5. vcpkg (C++ package manager)
The build script will attempt to install vcpkg automatically, or you can install manually:
```powershell
cd C:\
git clone https://github.com/Microsoft/vcpkg.git
cd vcpkg
.\bootstrap-vcpkg.bat
setx VCPKG_ROOT "C:\vcpkg"
```

## Build Steps

### Option A: Automatic Build (Recommended)

1. Open Command Prompt as Administrator
2. Navigate to this directory
3. Run:
   ```
   build_windows.bat
   ```
4. Wait for the build to complete
5. Find `GFootball_Setup.exe` in the current directory

### Option B: Manual Build

1. **Install vcpkg dependencies:**
   ```
   vcpkg install sdl2:x64-windows sdl2-image:x64-windows sdl2-ttf:x64-windows sdl2-gfx:x64-windows boost-python:x64-windows boost-filesystem:x64-windows boost-thread:x64-windows boost-system:x64-windows
   ```

2. **Clone and install gfootball:**
   ```
   git clone https://github.com/google-research/football.git
   cd football
   pip install .
   ```

3. **Install PyInstaller:**
   ```
   pip install pyinstaller
   ```

4. **Create the executable:**
   ```
   pyinstaller gfootball_game.spec --clean
   ```

5. **Copy data files:**
   ```
   xcopy /E /I /Y gfootball_engine\data dist\gfootball\data
   xcopy /E /I /Y gfootball_engine\fonts dist\gfootball\fonts
   ```

6. **Create installer:**
   ```
   makensis installer.nsi
   ```

## Files Included

- `build_windows.bat` - Main build script
- `gfootball_game.spec` - PyInstaller specification file
- `launcher.py` - Game launcher script
- `installer.nsi` - NSIS installer script
- `README.md` - This file

## Troubleshooting

### "Python not found"
- Ensure Python is installed and added to PATH
- Try running: `python --version`

### "vcpkg install fails"
- Run Command Prompt as Administrator
- Ensure you have enough disk space (~5GB)
- Check internet connection

### "Build fails at C++ compilation"
- Ensure Visual Studio Build Tools are installed
- Check that CMAKE can find the compiler

### "NSIS not found"
- Install NSIS from https://nsis.sourceforge.io
- Add NSIS installation directory to PATH

## Output

After successful build:
- `dist/gfootball/` - Portable application folder
- `GFootball_Setup.exe` - Windows installer

## Game Controls

- Arrow Keys: Move player
- S: Short pass (attack) / Pressure (defense)
- A: High pass (attack) / Slide (defense)
- D: Shoot (attack) / Team pressure (defense)
- W: Long pass
- Q: Switch active player
- C: Dribble
- E: Sprint
- Ctrl+C: Quit game

## License

Google Research Football is licensed under Apache 2.0.
See the LICENSE file for details.
