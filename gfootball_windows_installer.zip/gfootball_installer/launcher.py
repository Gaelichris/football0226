#!/usr/bin/env python3
"""Google Research Football Game Launcher"""

import sys
import os

# Ensure the bundled directory is in path
if getattr(sys, 'frozen', False):
    # Running as compiled
    application_path = os.path.dirname(sys.executable)
    os.chdir(application_path)
    sys.path.insert(0, application_path)

def main():
    """Launch the Google Research Football game."""
    try:
        import gfootball.env as football_env
        
        # Create environment
        env = football_env.create_environment(
            env_name='11_vs_11_easy_stochastic',
            render=True,
            representation='raw',
            number_of_left_players_agent_controls=1,
            stacked=False,
            write_video=False,
            write_full_episode_dumps=False,
            write_goal_dumps=False
        )
        
        print("Google Research Football")
        print("=" * 40)
        print("Controls:")
        print("  Arrow Keys - Move player")
        print("  S - Short pass / Pressure")
        print("  A - High pass / Slide")
        print("  D - Shoot / Team pressure")
        print("  W - Long pass")
        print("  Q - Switch player")
        print("  C - Dribble")
        print("  E - Sprint")
        print("=" * 40)
        print("Press Ctrl+C to quit")
        
        # Run game loop
        obs = env.reset()
        done = False
        
        while True:
            # Let the built-in keyboard controller handle input
            action = 0  # Idle action, keyboard will override
            obs, reward, done, info = env.step(action)
            
            if done:
                obs = env.reset()
                
    except KeyboardInterrupt:
        print("\nGame ended by user")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        input("Press Enter to exit...")
    finally:
        try:
            env.close()
        except:
            pass

if __name__ == '__main__':
    main()
