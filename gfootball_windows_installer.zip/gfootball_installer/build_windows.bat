@echo off
REM Google Research Football - Windows Build Script
REM This script builds gfootball and creates an installer

setlocal EnableDelayedExpansion

echo ============================================
echo  Google Research Football Windows Builder
echo ============================================
echo.

REM Check for administrator privileges
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [WARNING] Not running as administrator. Some operations may fail.
    echo.
)

REM Check Python
python --version >nul 2>&1
if %errorLevel% neq 0 (
    echo [ERROR] Python not found. Please install Python 3.8+ from python.org
    echo Download: https://www.python.org/downloads/
    pause
    exit /b 1
)
echo [OK] Python found

REM Check pip
python -m pip --version >nul 2>&1
if %errorLevel% neq 0 (
    echo [ERROR] pip not found.
    pause
    exit /b 1
)
echo [OK] pip found

REM Check Git
git --version >nul 2>&1
if %errorLevel% neq 0 (
    echo [ERROR] Git not found. Please install Git from git-scm.com
    pause
    exit /b 1
)
echo [OK] Git found

REM Check VCPKG_ROOT
if not defined VCPKG_ROOT (
    echo [WARNING] VCPKG_ROOT not set. Will try to install vcpkg...
    call :install_vcpkg
)
echo [OK] VCPKG_ROOT = %VCPKG_ROOT%

echo.
echo ============================================
echo  Step 1: Install Python Dependencies
echo ============================================
echo.

python -m pip install --upgrade pip setuptools wheel
python -m pip install pyinstaller pygame opencv-python psutil numpy absl-py six gym==0.21.0

echo.
echo ============================================
echo  Step 2: Install vcpkg Dependencies
echo ============================================
echo.

if exist "%VCPKG_ROOT%\vcpkg.exe" (
    "%VCPKG_ROOT%\vcpkg.exe" install sdl2:x64-windows sdl2-image:x64-windows sdl2-ttf:x64-windows sdl2-gfx:x64-windows boost-python:x64-windows boost-filesystem:x64-windows boost-thread:x64-windows boost-system:x64-windows
) else (
    echo [ERROR] vcpkg.exe not found at %VCPKG_ROOT%
    pause
    exit /b 1
)

echo.
echo ============================================
echo  Step 3: Clone and Build gfootball
echo ============================================
echo.

if not exist "football" (
    git clone https://github.com/google-research/football.git
)

cd football
python -m pip install .
if %errorLevel% neq 0 (
    echo [ERROR] gfootball build failed
    pause
    exit /b 1
)

echo.
echo ============================================
echo  Step 4: Create PyInstaller Package
echo ============================================
echo.

REM Create spec file
echo Creating PyInstaller spec file...
python create_spec.py

REM Run PyInstaller
pyinstaller gfootball_game.spec --clean

echo.
echo ============================================
echo  Step 5: Create NSIS Installer
echo ============================================
echo.

REM Copy data files
xcopy /E /I /Y "gfootball_engine\data" "dist\gfootball\data"
xcopy /E /I /Y "gfootball_engine\fonts" "dist\gfootball\fonts"

REM Run NSIS
makensis installer.nsi

echo.
echo ============================================
echo  BUILD COMPLETE!
echo ============================================
echo.
echo Installer created: GFootball_Setup.exe
echo.
pause
exit /b 0

:install_vcpkg
echo Installing vcpkg...
cd %USERPROFILE%
if not exist "vcpkg" (
    git clone https://github.com/Microsoft/vcpkg.git
)
cd vcpkg
call bootstrap-vcpkg.bat
set VCPKG_ROOT=%USERPROFILE%\vcpkg
setx VCPKG_ROOT "%VCPKG_ROOT%"
cd %~dp0
goto :eof
